<?php
include_once("function.php");
		if (isset($_GET['id'])) {
			$user_id = $_GET['id'];
		}else{};


   		$query2 = "SELECT * FROM deposit WHERE U_ID = '$user_id' AND Deposit_Date BETWEEN '$lmfd' AND '$lmld' ;";
		$result2 =mysqli_query($conn, $query2);
		while ($row2 = mysqli_fetch_assoc($result2)) {
 	 		  $member_amount[] =  $row2['Amount']; 
			}

		if (empty($member_amount)) {
			$member_sum = 0;
		}else{
			$member_sum = array_sum($member_amount);
		}
   		
		$query3 = "SELECT * FROM mill_info WHERE U_ID = '$user_id' AND Date BETWEEN '$lmfd' AND '$lmld' ;";
		$result3 =mysqli_query($conn, $query3);
		while ($row1 = mysqli_fetch_assoc($result3)) {
 	 		  $member_mill[] =  $row1['Mill_Count']; 
			}
		if (empty($member_mill)) {
			$mill_sum = 0;
		}else{
			$mill_sum = array_sum($member_mill);
		}

        $sql1 = "SELECT * FROM user WHERE `ID` = '$user_id';";
        $result4 = mysqli_query($conn, $sql1);
        $user = mysqli_fetch_assoc($result4);


        $sql = "SELECT * FROM user;";
        $result3 = mysqli_query($conn, $sql);
        $Alluser = mysqli_num_rows($result3);

        $statement = "SELECT * FROM extra WHERE extra_date BETWEEN '$lmfd' AND '$lmld' ;";
        $result4 =mysqli_query($conn, $statement);
        while ($row3 = mysqli_fetch_assoc($result4)) {
            $extra_cost_array[] =  $row3['extra_amount'];
        }
        if (empty($extra_cost_array)) {
            $extra_cost = 0;
        }else{
            $extra_cost = array_sum($extra_cost_array);
        }
        $final_extra = $extra_cost / ($Alluser - 1);

		$member_sub_cost = ($mill_rate * $mill_sum) + $final_extra;

		if ($member_sub_cost < $member_sum) {
			$member1_cost = ($member_sum - $member_sub_cost);
			if ($member1_cost == 0) {
				paidUpdateById($user_id);
                $member_cost = "Paid";
			}else{
				$member_cost = "Get ". $member1_cost;
			}
		}else{
			$member_cost1 = ($member_sub_cost - $member_sum);
			if ($member_cost1 == 0) {
                paidUpdateById($user_id);
                $member_cost = "Paid";
			}else{
				$member_cost = "Give ". $member_cost1;
			}
		}

?>