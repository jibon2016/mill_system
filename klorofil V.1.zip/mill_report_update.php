<?php 
include_once("header.php");
include_once("function.php");
require("mill_calculation.php");
 ?>
<!-- MAIN -->
<div class="main">
	<!-- MAIN CONTENT -->
	<div class="main-content">
		<div class="container-fluid">
			<h3 class="text-center">Mill Report</h3>
						<hr/>
			<div class="col-md-6 col-md-offset-3">
				<table class="table " >
					<tr>
						<th width="200" class="text-right" >Name:</th>
						<td><?php echo $user['NAME']; ?></td>
					</tr>
					<tr>
						<th width="200" class="text-right" > Mill:</th>
						<td><?php echo $mill_sum ;?></td>
					</tr>
					<tr>
						<th width="200" class="text-right" > Deposit:</th>
						<td><?php echo $member_sum; ?></td>
					</tr>
					<tr>
						<th width="200" class="text-right" >Mill Rate:</th>
						<td><?php echo $mill_rate; ?></td>
					</tr>
                    <tr>
                        <th width="200" class="text-right" > Extra:</th>
                        <?php if ($user['ROLE'] == 'admin'){?>
                            <td><?php echo "0"; ?></td>
                        <?php }else{?>
                            <td><?php echo $final_extra; ?></td>
                        <?php }?>
                    </tr>
					<tr>
						<th width="200" class="text-right" > Cost:</th>
                        <td><?php echo $member_cost; ?></td>
					</tr>
                    <tr>
                        <th width="200" class="text-right" > Status:</th>
                        <?php if ($user['paid_status'] == 1){?>
                            <td class="bg-success" style="color: #fff; font-weight: bold">Paid</td>
                        <?php }else{?>
                            <td class="bg-danger" style="color: #fff; font-weight: bold"> Not Paid</td>
                        <?php }?>
                    </tr>
					<div class="user_img text-center">
						<img width="200" height="200" src="<?php echo $url ."user/" . $user['U_Image'];?>" alt="Image">
					</div>
				</table>
			</div>
		</div>
	</div>
	<!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->
		
<?php 
include_once("footer.php");
?>