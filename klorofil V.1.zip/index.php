<?php 
include_once("header.php");
$month_first_date =  $first_date->format('M-d-Y');
$month_last_date =   $last_date->format('M-d-Y');

$sql_date_f =   $first_date->format('Y-m-d');
$sql_date_e =   $last_date->format('Y-m-d');

$role =  $_SESSION['ROLE'];


//For total Deposit
    $query = "SELECT * FROM deposit WHERE Deposit_Date BETWEEN '$sql_date_f' AND '$sql_date_e' AND approve_by_manager = 1;";
    $result_deposit= mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($result_deposit)) {
        $deposit_amount[] =  $row['Amount'];
    }
    if (empty($deposit_amount)) {
        $total_deposit = 0;
    }else{
        $total_deposit = array_sum($deposit_amount);
    }

//End total Deposit

//For total Bazar
    $query1 = "SELECT * FROM bazar_list WHERE B_Date BETWEEN '$sql_date_f' AND '$sql_date_e' AND approve_by_manager = 1;";
    $result_bazar= mysqli_query($conn, $query1);
    while ($row1 = mysqli_fetch_assoc($result_bazar)) {
        $bazar_amount[] =  $row1['B_Amount'];
    }
    if (empty($bazar_amount)) {
        $total_bazar = 0;
    }else{
        $total_bazar = array_sum($bazar_amount);
    }
//End total Bazar

//Takeable Cost
    $takeable_cost = $total_deposit - $total_bazar;


//For total Bazar
    $query2 = "SELECT * FROM mill_info WHERE Date BETWEEN '$sql_date_f' AND '$sql_date_e'";
    $result_mill= mysqli_query($conn, $query2);
    while ($row2 = mysqli_fetch_assoc($result_mill)) {
        $add_mill[] =  $row2['Mill_Count'];
    }
    if (empty($add_mill)) {
        $total_mill = 0;
    }else{
        $total_mill = array_sum($add_mill);
    }
//End total Bazar

 ?>
<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <div class="panel panel-headline">
                <div class="panel-heading">
                    <h3 class="panel-title">Monthly Overview</h3>
                    <p style="font-size: 20px;" class="panel-subtitle">Period: <?php echo $month_first_date ?> - <?php echo $month_last_date?></p>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="metric">
                                <span class="icon"><i class="fa fa-download"></i></span>
                                <p>
                                    <span class="number"><?php echo $total_deposit; ?>/=</span>
                                    <span class="title">Total Deposit</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="metric">
                                <span class="icon"><i class="fa fa-shopping-bag"></i></span>
                                <p>
                                    <span class="number"><?php echo $total_bazar; ?>/=</span>
                                    <span class="title">Total Bazar</span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="metric">
                                <span class="icon"><i class="fa fa-eye"></i></span>
                                <p>
                                    <span class="number"><?php echo $takeable_cost; ?>/=</span>
                                    <span class="title">Takeable Cost </span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="metric">
                                <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                <p>
                                    <span class="number"><?php echo $total_mill; ?></span>
                                    <span class="title">Total Mill</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-9">
                            <div id="headline-chart" class="ct-chart"></div>
                        </div>
                        <div class="col-md-3">
                            <div class="weekly-summary text-right">
                                <span class="number">2,315</span> <span class="percentage"><i class="fa fa-caret-up text-success"></i> 12%</span>
                                <span class="info-label">Total Sales</span>
                            </div>
                            <div class="weekly-summary text-right">
                                <span class="number">$5,758</span> <span class="percentage"><i class="fa fa-caret-up text-success"></i> 23%</span>
                                <span class="info-label">Monthly Income</span>
                            </div>
                            <div class="weekly-summary text-right">
                                <span class="number">$65,938</span> <span class="percentage"><i class="fa fa-caret-down text-danger"></i> 8%</span>
                                <span class="info-label">Total Income</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END OVERVIEW -->
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->

<?php 
include_once("footer.php");
?>